<div class="orsm-hero">

<div class="orsm-kicker">
Operational Resilience Security Model
</div>

<!-- ORSM-HOMEPAGE-ACTIONS-START -->

<div class="orsm-home-actions">

<a href="model/" class="orsm-action orsm-action-primary">
Explore the Model <span>→</span>
</a>

<a href="assessment/" class="orsm-action orsm-action-secondary">
Apply ORSM <span>→</span>
</a>

</div>

<p class="orsm-practice-link">
Or see how ORSM works <a href="in-practice/">In Practice →</a>
</p>

<!-- ORSM-HOMEPAGE-ACTIONS-END -->


<div class="orsm-hero-title">
Security architecture that survives contact with reality.
</div>

<div class="orsm-hero-copy" markdown>
ORSM is an architectural assurance framework for evaluating whether security controls continue to provide effective protection without creating disproportionate operational risk.
</div>

<div class="orsm-hero-rule"></div>

</div>


<div class="orsm-split" markdown>

<div class="orsm-split-label">
The problem
</div>

<div class="orsm-split-content" markdown>

## Security can become a source of operational risk

Modern security programmes have become increasingly capable, interconnected and heavily governed.

Yet individually justified controls can combine to produce architectures that are difficult to operate, expensive to maintain, dependent upon a small number of strategic platforms and challenging to recover when those platforms fail.

ORSM calls this the **Operational Security Paradox**.

</div>

</div>


<div class="orsm-split" markdown>

<div class="orsm-split-label">
The governing question
</div>

<div class="orsm-split-content" markdown>

> **Does this control improve security outcomes without creating disproportionate operational risk?**

ORSM does not ask organisations to weaken security.

It asks whether security remains **proportionate, sustainable, recoverable and operationally resilient** once controls become part of a living enterprise architecture.

</div>

</div>


<div class="orsm-split" markdown>

<div class="orsm-split-label">
07 domains
</div>

<div class="orsm-split-content" markdown>

## Operational Assessment Domains

ORSM evaluates architectural quality across seven dimensions.

<div class="orsm-domain-grid">

<div class="orsm-domain">
<span class="orsm-domain-number">01</span>
<div class="orsm-domain-title">Protection Intent</div>
<div class="orsm-domain-copy" markdown>Does every capability exist for a clear and continuing business purpose?</div>
</div>

<div class="orsm-domain">
<span class="orsm-domain-number">02</span>
<div class="orsm-domain-title">Complexity Management</div>
<div class="orsm-domain-copy" markdown>Is architectural complexity understood, justified and actively controlled?</div>
</div>

<div class="orsm-domain">
<span class="orsm-domain-number">03</span>
<div class="orsm-domain-title">Operational Sustainability</div>
<div class="orsm-domain-copy" markdown>Can the organisation realistically operate and maintain the architecture?</div>
</div>

<div class="orsm-domain">
<span class="orsm-domain-number">04</span>
<div class="orsm-domain-title">Operational Resilience</div>
<div class="orsm-domain-copy" markdown>Can critical services continue when security capabilities fail?</div>
</div>

<div class="orsm-domain">
<span class="orsm-domain-number">05</span>
<div class="orsm-domain-title">Recovery Engineering</div>
<div class="orsm-domain-copy" markdown>Can security capability be restored rapidly, repeatably and predictably?</div>
</div>

<div class="orsm-domain">
<span class="orsm-domain-number">06</span>
<div class="orsm-domain-title">Human Factors</div>
<div class="orsm-domain-copy" markdown>Do controls align with realistic human and operational behaviour?</div>
</div>

<div class="orsm-domain">
<span class="orsm-domain-number">07</span>
<div class="orsm-domain-title">Dependency Resilience</div>
<div class="orsm-domain-copy" markdown>Does concentration on platforms, vendors or services create systemic risk?</div>
</div>

</div>

</div>

</div>


<div class="orsm-split" markdown>

<div class="orsm-split-label">
The model
</div>

<div class="orsm-split-content" markdown>

## Assurance beyond control presence

Traditional security assurance commonly asks whether expected controls have been implemented.

ORSM asks whether those controls continue to deliver meaningful protection **without degrading the organisation's ability to operate and recover**.

The framework combines:

- eight Foundational Principles;
- five Assurance Tests;
- seven Operational Assessment Domains;
- evidence-based assessment;
- architectural decision outcomes;
- measurable operational indicators; and
- a five-level capability maturity model.

</div>

</div>


<div class="orsm-split" markdown>

<div class="orsm-split-label">
Relationship to existing frameworks
</div>

<div class="orsm-split-content" markdown>

## Complement, not replacement

ORSM is designed to sit alongside established approaches including:

**NIST CSF 2.0 · ISO/IEC 27001 · NCSC Secure by Design · SABSA · Zero Trust**

These approaches establish important security capabilities, governance and design principles.

ORSM evaluates the resulting architecture through an additional operational lens:

**Is it sustainable? Is it recoverable? Is it proportionate? Can the organisation still operate when it fails?**

</div>

</div>


<div class="orsm-statement">

Security is not measured by the controls we deploy.

It is measured by the architecture we can continue to operate.

</div>

**Operational security is proven through survivability.**
