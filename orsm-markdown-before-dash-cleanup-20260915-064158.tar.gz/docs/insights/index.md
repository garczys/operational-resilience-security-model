---
title: ORSM Insights
description: Analysis, observations and developing thinking around security architecture, operational resilience and the Operational Resilience Security Model.
---

# ORSM Insights

**Analysis, observations and developing thinking around security architecture, operational resilience and related disciplines.**

ORSM Insights provides a space to explore ideas surrounding the framework without turning every observation into an additional framework requirement.

The articles may examine architectural complexity, operational resilience, security assurance, Secure by Design, human factors, emerging technology and lessons drawn from real-world security architecture.

!!! info "Insights and the ORSM Framework"
    ORSM Insights are intended to encourage discussion, reflection and constructive challenge.

    They do **not** form part of the normative ORSM framework and do not introduce additional assessment requirements.

---

## Latest Insight

### The Implementation Gap

**Your threat model may not be wrong. Your architecture may have moved on.**

Threat knowledge can remain valuable even when the architecture, trust relationships, dependencies, control effectiveness and consequence around it have changed.

Insight 003 explores why threat modelling should follow material architectural change rather than simply expire with age.

[Read Insight 003 →](insight-003-the-implementation-gap.md)

---

### Control Fatigue

**Does it really need to be this way?**

Insight 002 explores control accumulation, architectural complexity, operational burden and whether every control we continue to operate still provides proportionate security value.

[Read Insight 002 →](control-fatigue.md)

---

### Individually Rational Controls Can Produce Collectively Irrational Architectures

Security controls are rarely introduced without reason.

Each may address a legitimate threat, regulatory obligation, audit finding or recognised security practice.

The difficulty can emerge when individually reasonable decisions accumulate into an architecture that is increasingly difficult to understand, operate, recover or change.

[Read Insight 001 →](individually-rational-controls.md)

---

## Constructive Challenge

ORSM is intended to encourage architectural judgement rather than prescribe universal answers.

Different experiences, environments and conclusions are therefore valuable.

Questions, practitioner feedback and constructive challenge are welcome at:

**hello@orsmframework.org**

Please do not send classified, commercially sensitive, customer-identifiable or security-sensitive information.
