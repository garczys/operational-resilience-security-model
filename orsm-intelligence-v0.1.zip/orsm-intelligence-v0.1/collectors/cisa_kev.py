#!/usr/bin/env python3
"""
ORSM Operational Threat Intelligence - CISA KEV collector.

Design goals:
- No third-party Python dependencies.
- Prefer CISA canonical JSON feed.
- Fall back to the official cisagov/kev-data GitHub mirror.
- Validate basic structure before replacing known-good output.
- Atomic writes: malformed/partial data never replaces current.json.
- Deterministic enrichment only; no AI-generated risk judgements.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

CISA_CANONICAL = (
    "https://www.cisa.gov/sites/default/files/feeds/"
    "known_exploited_vulnerabilities.json"
)
CISA_GITHUB_MIRROR = (
    "https://raw.githubusercontent.com/cisagov/kev-data/develop/"
    "known_exploited_vulnerabilities.json"
)

USER_AGENT = "ORSM-Operational-Threat-Intelligence/0.1 (+https://orsmframework.org)"
MAX_DOWNLOAD_BYTES = 12 * 1024 * 1024
TIMEOUT_SECONDS = 20


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def fetch_json(url: str) -> tuple[dict[str, Any], bytes]:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "application/json",
            "Cache-Control": "no-cache",
        },
    )

    with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
        content_type = response.headers.get("Content-Type", "")
        raw = response.read(MAX_DOWNLOAD_BYTES + 1)

    if len(raw) > MAX_DOWNLOAD_BYTES:
        raise ValueError(f"Feed exceeded {MAX_DOWNLOAD_BYTES} bytes")

    # CISA/GitHub may vary the exact Content-Type, so treat this as defensive
    # telemetry rather than a hard failure.
    if "json" not in content_type.lower() and content_type:
        print(f"warning: unexpected Content-Type from {url}: {content_type}", file=sys.stderr)

    try:
        parsed = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Invalid JSON from {url}: {exc}") from exc

    if not isinstance(parsed, dict):
        raise ValueError("KEV feed root must be a JSON object")

    return parsed, raw


def validate_catalog(catalog: dict[str, Any]) -> list[dict[str, Any]]:
    required_root = ("catalogVersion", "dateReleased", "count", "vulnerabilities")
    missing = [key for key in required_root if key not in catalog]
    if missing:
        raise ValueError(f"KEV catalogue missing root fields: {', '.join(missing)}")

    vulnerabilities = catalog["vulnerabilities"]
    if not isinstance(vulnerabilities, list):
        raise ValueError("'vulnerabilities' must be a list")

    if not vulnerabilities:
        raise ValueError("KEV catalogue unexpectedly contains zero vulnerabilities")

    # A catastrophically truncated feed should not overwrite known-good data.
    declared_count = catalog.get("count")
    if isinstance(declared_count, int) and declared_count != len(vulnerabilities):
        raise ValueError(
            f"Declared count {declared_count} does not match actual "
            f"count {len(vulnerabilities)}"
        )

    required_item = (
        "cveID",
        "vendorProject",
        "product",
        "vulnerabilityName",
        "dateAdded",
        "shortDescription",
        "requiredAction",
        "dueDate",
    )

    seen: set[str] = set()
    for index, item in enumerate(vulnerabilities):
        if not isinstance(item, dict):
            raise ValueError(f"Entry {index} is not an object")

        absent = [key for key in required_item if not item.get(key)]
        if absent:
            raise ValueError(
                f"Entry {index} missing required fields: {', '.join(absent)}"
            )

        cve = str(item["cveID"]).strip().upper()
        if not cve.startswith("CVE-"):
            raise ValueError(f"Entry {index} has unexpected CVE identifier: {cve}")

        if cve in seen:
            raise ValueError(f"Duplicate CVE detected: {cve}")
        seen.add(cve)

    return vulnerabilities


def classify(item: dict[str, Any]) -> dict[str, Any]:
    """
    Deterministic, transparent ORSM-oriented tags.

    These are *triage hints*, not organisational risk ratings.
    An organisation must still establish technology presence, exposure,
    trust relationships, consequence and compensating controls.
    """
    haystack = " ".join(
        str(item.get(k, ""))
        for k in ("vendorProject", "product", "vulnerabilityName", "shortDescription")
    ).lower()

    tags: set[str] = {"Known Exploited"}

    keyword_tags = {
        "Identity": (
            "identity", "active directory", "entra", "authentication",
            "single sign-on", "sso", "ldap", "oauth", "saml",
        ),
        "Privileged Access": (
            "administrator", "privilege", "privileged", "management",
            "hypervisor", "vcenter", "esxi",
        ),
        "Remote Access": (
            "vpn", "remote access", "remote code execution", "gateway",
            "edge device",
        ),
        "Network Infrastructure": (
            "router", "firewall", "switch", "network", "gateway",
        ),
        "Virtualisation": (
            "vmware", "hyper-v", "hypervisor", "virtualization", "virtualisation",
        ),
        "Web / Application": (
            "web", "http", "browser", "application", "server",
        ),
        "OT / ICS": (
            "industrial", "scada", "plc", "ics", "operational technology",
        ),
        "Cloud / Platform": (
            "cloud", "kubernetes", "container", "platform",
        ),
    }

    for tag, keywords in keyword_tags.items():
        if any(keyword in haystack for keyword in keywords):
            tags.add(tag)

    ransomware = str(item.get("knownRansomwareCampaignUse", "")).strip().lower()
    if ransomware == "known":
        tags.add("Known Ransomware Use")

    # Architectural attention is intentionally not labelled "risk".
    # It only raises visibility where compromise may plausibly have broad reach.
    high_attention_terms = (
        "remote code execution",
        "authentication bypass",
        "privilege escalation",
        "administrator",
        "management",
        "hypervisor",
        "vpn",
        "gateway",
        "firewall",
    )
    attention = "Elevated" if any(term in haystack for term in high_attention_terms) else "Standard"

    return {
        "architectureTags": sorted(tags),
        "architecturalAttention": attention,
    }


def normalise(
    catalog: dict[str, Any],
    source_url: str,
    raw: bytes,
) -> dict[str, Any]:
    vulnerabilities = validate_catalog(catalog)

    records = []
    for item in vulnerabilities:
        enriched = classify(item)
        records.append(
            {
                "id": item["cveID"],
                "cve": item["cveID"],
                "vendor": item["vendorProject"],
                "product": item["product"],
                "title": item["vulnerabilityName"],
                "dateAdded": item["dateAdded"],
                "description": item["shortDescription"],
                "requiredAction": item["requiredAction"],
                "dueDate": item["dueDate"],
                "knownRansomwareCampaignUse": item.get(
                    "knownRansomwareCampaignUse", "Unknown"
                ),
                "notes": item.get("notes", ""),
                "cwes": item.get("cwes", []),
                "source": {
                    "publisher": "CISA",
                    "catalogue": "Known Exploited Vulnerabilities (KEV)",
                    "canonicalUrl": "https://www.cisa.gov/known-exploited-vulnerabilities-catalog",
                    "retrievedFrom": source_url,
                },
                **enriched,
            }
        )

    # Latest additions first. CVE used as deterministic tiebreaker.
    records.sort(key=lambda r: (r["dateAdded"], r["cve"]), reverse=True)

    return {
        "schemaVersion": "orsm-intelligence-0.1",
        "generatedAt": utc_now(),
        "sourceCatalogVersion": catalog["catalogVersion"],
        "sourceDateReleased": catalog["dateReleased"],
        "sourceRecordCount": catalog["count"],
        "sourceSha256": hashlib.sha256(raw).hexdigest(),
        "methodology": {
            "statement": (
                "ORSM architectural tags are deterministic triage hints. "
                "They are not vulnerability severity or organisational risk ratings."
            )
        },
        "records": records,
    }


def atomic_write_json(data: dict[str, Any], destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)

    fd, temp_name = tempfile.mkstemp(
        prefix=f".{destination.name}.",
        suffix=".tmp",
        dir=str(destination.parent),
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, destination)
    finally:
        if os.path.exists(temp_name):
            os.unlink(temp_name)


def collect(destination: Path) -> str:
    errors: list[str] = []

    for url in (CISA_CANONICAL, CISA_GITHUB_MIRROR):
        try:
            catalog, raw = fetch_json(url)
            output = normalise(catalog, url, raw)
            atomic_write_json(output, destination)
            return url
        except (urllib.error.URLError, TimeoutError, ValueError, OSError) as exc:
            errors.append(f"{url}: {exc}")

    raise RuntimeError(
        "No trusted KEV source produced a valid catalogue. "
        "Known-good output was left untouched.\n" + "\n".join(errors)
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="docs/intelligence/data/current.json",
        help="Destination JSON file",
    )
    args = parser.parse_args()

    destination = Path(args.output)

    try:
        source = collect(destination)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    print(f"ORSM intelligence updated from: {source}")
    print(f"Wrote: {destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
