(() => {
  "use strict";

  const DATA_URL = "/intelligence/data/current.json";

  const els = {
    status: document.getElementById("orsm-intel-status"),
    search: document.getElementById("orsm-intel-search"),
    tag: document.getElementById("orsm-intel-tag"),
    window: document.getElementById("orsm-intel-window"),
    summary: document.getElementById("orsm-intel-summary"),
    results: document.getElementById("orsm-intel-results"),
  };

  if (!els.results) return;

  let dataset = null;

  const escapeHtml = (value) => String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

  function daysAgo(dateText) {
    const then = new Date(`${dateText}T00:00:00Z`);
    return (Date.now() - then.getTime()) / 86400000;
  }

  function recordMatches(record) {
    const q = els.search.value.trim().toLowerCase();
    const tag = els.tag.value;
    const windowDays = Number(els.window.value);

    if (tag && !(record.architectureTags || []).includes(tag)) return false;
    if (windowDays > 0 && daysAgo(record.dateAdded) > windowDays) return false;

    if (!q) return true;

    const haystack = [
      record.cve,
      record.vendor,
      record.product,
      record.title,
      record.description,
      ...(record.architectureTags || []),
    ].join(" ").toLowerCase();

    return haystack.includes(q);
  }

  function renderCard(record) {
    const tags = (record.architectureTags || [])
      .map(tag => `<span class="orsm-intel-tag">${escapeHtml(tag)}</span>`)
      .join("");

    const ransomware = String(record.knownRansomwareCampaignUse).toLowerCase() === "known"
      ? `<span class="orsm-intel-alert">KNOWN RANSOMWARE USE</span>`
      : "";

    const attentionClass = record.architecturalAttention === "Elevated"
      ? "orsm-attention-elevated"
      : "orsm-attention-standard";

    return `
      <article class="orsm-intel-card">
        <div class="orsm-intel-card-top">
          <div>
            <span class="orsm-intel-kev">KNOWN EXPLOITED</span>
            ${ransomware}
          </div>
          <time datetime="${escapeHtml(record.dateAdded)}">
            Added ${escapeHtml(record.dateAdded)}
          </time>
        </div>

        <h2>${escapeHtml(record.cve)} — ${escapeHtml(record.vendor)} ${escapeHtml(record.product)}</h2>
        <h3>${escapeHtml(record.title)}</h3>

        <p>${escapeHtml(record.description)}</p>

        <div class="orsm-intel-tags">${tags}</div>

        <dl class="orsm-intel-facts">
          <div>
            <dt>Architectural attention</dt>
            <dd class="${attentionClass}">${escapeHtml(record.architecturalAttention)}</dd>
          </div>
          <div>
            <dt>CISA required action</dt>
            <dd>${escapeHtml(record.requiredAction)}</dd>
          </div>
          <div>
            <dt>CISA due date</dt>
            <dd>${escapeHtml(record.dueDate)}</dd>
          </div>
        </dl>

        <details>
          <summary>Assess architectural relevance</summary>
          <div class="orsm-triage">
            <p><strong>Ask:</strong></p>
            <ul>
              <li>Is the affected technology and version present?</li>
              <li>Where does it sit architecturally?</li>
              <li>Does it cross or control a trust boundary?</li>
              <li>What privileged or administrative reach could compromise provide?</li>
              <li>Which compensating controls are independently enforced?</li>
              <li>What is the consequence of compromise?</li>
              <li>What is the consequence of emergency isolation or remediation?</li>
              <li>Can the capability and its dependencies be recovered safely?</li>
            </ul>
            <p class="orsm-intel-note">
              ORSM architectural attention is a triage hint, not an organisational risk rating.
            </p>
          </div>
        </details>

        <div class="orsm-intel-source">
          Source: <a href="${escapeHtml(record.source.canonicalUrl)}"
          target="_blank" rel="noopener noreferrer">CISA KEV</a>
        </div>
      </article>
    `;
  }

  function render() {
    const matches = dataset.records.filter(recordMatches);
    const elevated = matches.filter(
      item => item.architecturalAttention === "Elevated"
    ).length;
    const ransomware = matches.filter(
      item => String(item.knownRansomwareCampaignUse).toLowerCase() === "known"
    ).length;

    els.summary.innerHTML = `
      <div><strong>${matches.length}</strong><span>matching KEVs</span></div>
      <div><strong>${elevated}</strong><span>elevated architectural attention</span></div>
      <div><strong>${ransomware}</strong><span>known ransomware use</span></div>
    `;

    if (!matches.length) {
      els.results.innerHTML = `<p class="orsm-intel-empty">No matching intelligence items.</p>`;
      return;
    }

    // Avoid dumping the whole historical KEV catalogue into the DOM at once.
    const visible = matches.slice(0, 100);
    els.results.innerHTML = visible.map(renderCard).join("");

    if (matches.length > visible.length) {
      els.results.insertAdjacentHTML(
        "beforeend",
        `<p class="orsm-intel-empty">Showing first ${visible.length} of ${matches.length} matches. Refine the filters to narrow the result.</p>`
      );
    }
  }

  function populateTags() {
    const tags = [...new Set(
      dataset.records.flatMap(record => record.architectureTags || [])
    )].sort();

    for (const tag of tags) {
      const option = document.createElement("option");
      option.value = tag;
      option.textContent = tag;
      els.tag.appendChild(option);
    }
  }

  async function load() {
    try {
      const response = await fetch(DATA_URL, {
        cache: "no-store",
        headers: { "Accept": "application/json" },
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      dataset = await response.json();

      if (!dataset || !Array.isArray(dataset.records)) {
        throw new Error("Unexpected intelligence data format");
      }

      populateTags();

      const generated = new Date(dataset.generatedAt);
      els.status.innerHTML = `
        <strong>Source:</strong> CISA Known Exploited Vulnerabilities
        &nbsp;·&nbsp;
        <strong>${dataset.sourceRecordCount}</strong> catalogue entries
        &nbsp;·&nbsp;
        Updated ${escapeHtml(generated.toLocaleString())}
      `;

      render();
    } catch (error) {
      console.error(error);
      els.status.innerHTML = `
        <strong>Intelligence unavailable.</strong>
        The previous site content remains available; no unvalidated feed data has been rendered.
      `;
    }
  }

  for (const el of [els.search, els.tag, els.window]) {
    el.addEventListener("input", render);
    el.addEventListener("change", render);
  }

  load();
})();
