---
hide:
  - toc
---

# Operational Threat Intelligence

<div class="orsm-intel-intro">
Public threat information viewed through an architecture and operational-resilience lens.

**This is not a vulnerability scanner, risk rating service, or replacement for a dedicated threat-intelligence platform.**
It helps architects move from <em>“this is being exploited”</em> to <em>“does this matter to our architecture, and why?”</em>
</div>

<div class="orsm-intel-status" id="orsm-intel-status">
Loading current intelligence…
</div>

<div class="orsm-intel-controls">
  <label>
    Search
    <input id="orsm-intel-search" type="search" placeholder="CVE, vendor, product, keyword…">
  </label>

  <label>
    Architecture view
    <select id="orsm-intel-tag">
      <option value="">All</option>
    </select>
  </label>

  <label>
    Added
    <select id="orsm-intel-window">
      <option value="30">Last 30 days</option>
      <option value="7">Last 7 days</option>
      <option value="1">Last 24 hours</option>
      <option value="0">All KEV</option>
    </select>
  </label>
</div>

<div id="orsm-intel-summary" class="orsm-intel-summary"></div>
<div id="orsm-intel-results" class="orsm-intel-results"></div>

<noscript>
JavaScript is required to render the interactive intelligence list. The underlying data remains available as static JSON.
</noscript>

## How to interpret this page

CISA KEV establishes that a vulnerability is known to have been exploited in the wild. ORSM does not convert that fact into an organisational risk score.

The architecture assessment still needs to establish:

1. **Applicability** — do we operate the affected product/version?
2. **Architectural position** — where does it sit and what trust does it hold?
3. **Exposure** — what can reach it?
4. **Control context** — what independently enforced mitigations exist?
5. **Operational consequence** — what happens if it is compromised, isolated or patched?
6. **Recovery** — can the service and its dependencies be restored safely?

_Source: CISA Known Exploited Vulnerabilities catalogue. ORSM tags are deterministic triage hints only._
