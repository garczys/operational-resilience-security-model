import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from collectors.cisa_kev import classify, normalise, atomic_write_json


class KevCollectorTests(unittest.TestCase):
    def sample_catalog(self):
        return {
            "title": "CISA Catalog of Known Exploited Vulnerabilities",
            "catalogVersion": "test",
            "dateReleased": "2026-08-31T00:00:00.000Z",
            "count": 1,
            "vulnerabilities": [
                {
                    "cveID": "CVE-2026-12345",
                    "vendorProject": "Example",
                    "product": "Management Gateway",
                    "vulnerabilityName": "Example Remote Code Execution Vulnerability",
                    "dateAdded": "2026-08-31",
                    "shortDescription": "A remote code execution issue affects a management gateway.",
                    "requiredAction": "Apply mitigations per vendor instructions.",
                    "dueDate": "2026-09-01",
                    "knownRansomwareCampaignUse": "Unknown",
                    "notes": "",
                    "cwes": ["CWE-000"],
                }
            ],
        }

    def test_classification_is_deterministic(self):
        item = self.sample_catalog()["vulnerabilities"][0]
        result = classify(item)
        self.assertEqual(result["architecturalAttention"], "Elevated")
        self.assertIn("Remote Access", result["architectureTags"])
        self.assertIn("Privileged Access", result["architectureTags"])

    def test_normalise(self):
        raw = json.dumps(self.sample_catalog()).encode()
        result = normalise(self.sample_catalog(), "https://example.test/feed", raw)
        self.assertEqual(len(result["records"]), 1)
        self.assertEqual(result["records"][0]["cve"], "CVE-2026-12345")

    def test_atomic_write(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "current.json"
            atomic_write_json({"ok": True}, path)
            self.assertEqual(json.loads(path.read_text()), {"ok": True})


if __name__ == "__main__":
    unittest.main()
